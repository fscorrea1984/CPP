#include <iostream>
#include <sstream>
#include <string>
#include <utility>
#include <vector>
#include "grid.h"

using namespace std;

int main(int argc, char **argv) {

  int Q,L;
  string line;

  getline(cin,line);
  Q = stoi(line,nullptr,10);
  vector<Grid> grid;

  for(int i = 0; i < Q; i++) {

    getline(cin,line);
    L = stoi(line,nullptr,10);

    vector<string> v;

    for(int j = 0; j < L; j++) {

      getline(cin,line);
      stringstream str(line);
      string a,b;

      for(int k = 0; k < L; k++) {
	str >> b;
	a += b;
      }

      v.push_back(a);
      
    }

    Grid g(v,L);
    grid.push_back(g);
    
  }

  int grid_index = 0;

  while(grid_index < Q) {

    Grid& G = grid.at(grid_index);

    G.scan();

    float res = static_cast<float>(G.getcount(0)) + static_cast<float>(G.getcount(1));
    res /= 2.00f;

    cout.precision(2);

    cout << fixed << res << endl;

    ++grid_index;
      
  }
  
  return 0;
  
}
