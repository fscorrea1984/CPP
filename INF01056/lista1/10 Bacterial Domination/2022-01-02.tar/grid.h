#include <vector>

class Grid;

class Grid {
  
  std::vector<std::string> v;
  std::vector<int> count;
  int L;

 public:
  
  Grid(std::vector<std::string>,int);
  ~Grid();
  void scan();
  void check(int,int);
  int getcount(int);
  
};
