#include <iostream>
#include <sstream>
#include <string>
#include <utility>
#include <vector>
#include "grid.h"

using namespace std;

Grid::Grid(vector<string> vec,int l) : v(vec), count(2,0), L(l) {};

Grid::~Grid() {};

void Grid::scan() {

  for(int i = 0; i < L; i++)
    for(int j = 0; j < L; j++) {
      if(v.at(i).at(j) == '1')
	count.at(1)++;
      else
	check(i,j);
    }
  
}

void Grid::check(int i,int j) {

  // above

  for(int k = i; k >= 0; k--) {
    if(v.at(k).at(j) == '1')
      break;
    if(k-1 < 0)
      return;
  }

  // below

  for(int k = i; k < L; k++) {
    if(v.at(k).at(j) == '1')
      break;
    if(k+1 >= L)
      return;
  }

  // left

  for(int k = j; k >= 0; k--) {
    if(v.at(i).at(k) == '1')
      break;
    if(k-1 < 0)
      return;
  }

  // right

  for(int k = j; k < L; k++) {
    if(v.at(i).at(k) == '1')
      break;
    if(k+1 >= L)
      return;
  }

  count.at(0)++;

}

int Grid::getcount(int k) { return count.at(k); }
